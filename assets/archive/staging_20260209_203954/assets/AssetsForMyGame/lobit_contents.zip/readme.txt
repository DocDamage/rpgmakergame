
Thank you for for buying my graphics pack (or downloading, if you're a patron)!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
     LO-BIT RPG Pixel Art Assets
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Return to the classic era! This complete standalone collection contains everything you need for 
a full adventure. Heroes and villains, monsters, NPCs, soldiers, a royal family... and all sorts 
of quirky weirdos! Tiles and objects are included for a variety of classic RPG locations-- create 
a full interactive world with this unique 8-bit-inspired art style.

+ Complete set of environment tiles: make forests, villages, caves and more!
+ 20 character sprites with full four-direction walking animations
+ 64 additional character sprites with 3-frame idle animations
+ Every character has a color variant: Over 170 characters total!
+ Animated objects: Flames, Doors, Treasure Chests, Traps and Spikes
+ BONUS SHEET: Village, homes, and tower tiles for overworld maps
+ BONUS SHEET: Window-skin asset for message box and menus


Everything is organized in a format that can easily be used in RPG Maker-- but also includes a master 
sheet with everything on it. You are welcome to use these graphics in any engine of your choice!

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

How to best use the tiles:

Note that the terrain-layer tiles are made up of 8x8 tiles, intended to be placed in a semi-random pattern 
to create texture. To maximize the style of this tileset, I recommend making the terrain using an 8x8 grid 
and then an upper-layer with objects and collision using a 16x16​ grid. When combined together, this creates 
an appealing and unique style. 

You can see how this looks in my example screenshots.

-------------------------
Time Fantasy Website
 timefantasy.net

Artist's Website
 finalbossblues.com
Twitter
 @finalbossblues
Facebook
 finalbossblues