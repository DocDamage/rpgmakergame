
~ Happy Halloween 2025 ~

Thanks for downloading this small Elements add-on!

If you're using the Elements Generator, just copy these files into the subfolders 
(head or top) and then re-open the app.

These all use the default "skin tone" as explained in the Elements core. This means that
the generator will recognize and replace the skin tones; so you can use bone or gray etc.

If you're not using the generator then you can recolor them as needed for your project.

Notes:
The zomTop is intended to be used for skeletons too, but I kept the "zom" name,
so they're grouped together at the bottom of an alphabetical list.

Note on the skull: Just for convenience,
I've also included the skeleton head from the first Elements Expansion pack.
It's been renamed to fit the zom group.